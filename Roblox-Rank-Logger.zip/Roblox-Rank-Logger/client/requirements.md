## Packages
react-icons | Brand icons for Discord and Roblox
framer-motion | Smooth animations for lists and interactions

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}
